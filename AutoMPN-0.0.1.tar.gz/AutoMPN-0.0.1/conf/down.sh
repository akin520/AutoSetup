echo "download package start"
wget http://blog.s135.com/soft/linux/nginx_php/nginx/nginx-0.7.19.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/php/php-5.2.6.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/phpfpm/php-5.2.6-fpm-0.5.9.diff.gz
wget http://blog.s135.com/soft/linux/nginx_php/libiconv/libiconv-1.12.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/mcrypt/libmcrypt-2.5.8.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/mcrypt/mcrypt-2.6.7.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/memcache/memcache-2.2.3.tgz
wget http://blog.s135.com/soft/linux/nginx_php/mhash/mhash-0.9.9.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/pcre/pcre-7.7.tar.gz
wget http://blog.s135.com/soft/linux/nginx_php/eaccelerator/eaccelerator-0.9.5.3.tar.bz2
wget http://downloads.mysql.com/archives/mysql-5.0/mysql-5.0.22.tar.gz
echo "download package end!"