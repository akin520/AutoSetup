echo "download package start"
wget http://autosetup1.googlecode.com/files/nginx-0.7.19.tar.gz
wget http://autosetup1.googlecode.com/files/php-5.2.6.tar.gz
wget http://autosetup1.googlecode.com/files/php-5.2.6-fpm-0.5.9.diff.gz
wget http://autosetup1.googlecode.com/files/libiconv-1.12.tar.gz
wget http://autosetup1.googlecode.com/files/libmcrypt-2.5.8.tar.gz
wget http://autosetup1.googlecode.com/files/mcrypt-2.6.7.tar.gz
wget http://autosetup1.googlecode.com/files/memcache-2.2.3.tgz
wget http://autosetup1.googlecode.com/files/mhash-0.9.9.tar.gz
wget http://autosetup1.googlecode.com/files/pcre-7.7.tar.gz
wget http://autosetup1.googlecode.com/files/eaccelerator-0.9.5.3.tar.bz2
wget http://autosetup1.googlecode.com/files/mysql-5.0.22.tar.gz
echo "download package end!"