#!/bin/bash

wget http://autosetup2.googlecode.com/files/pam_mysql-0.7RC1.tar.gz
tar -zxvf pam_mysql-0.7RC1.tar.gz
cd pam_mysql-0.7RC1
./configure --with-openssl --with-mysql=/usr/local/mysql
make;make install
cd ..
echo "/lib/security" >> /etc/ld.so.conf
ldconfig