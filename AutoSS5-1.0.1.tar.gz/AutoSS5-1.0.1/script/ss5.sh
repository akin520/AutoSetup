#!/bin/bash

wget http://autosetup2.googlecode.com/files/ss5-3.6.4-3.tar.gz
tar -zxvf ss5-3.6.4-3.tar.gz 
cd ss5-3.6.4
./configure
make;make install
cd ..
