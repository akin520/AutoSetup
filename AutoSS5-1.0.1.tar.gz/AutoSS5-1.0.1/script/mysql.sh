#!/bin/bash
#
/usr/local/bin/mytget -n 10 -f mysql-5.1.31.tar.gz http://autosetup1.googlecode.com/files/mysql-5.1.31.tar.gz
tar -zxvf mysql-5.1.31.tar.gz
cd mysql-5.1.31
./configure --prefix=/usr/local/mysql/ --enable-assembler --with-extra-charsets=complex --enable-thread-safe-client --with-big-tables --with-readline --with-ssl --with-embedded-server --enable-local-infile --with-plugins=innobase
make;make install
cd ..
groupadd mysql
useradd -g mysql mysql
cp /usr/local/mysql/share/mysql/my-medium.cnf /etc/my.cnf
sed -i 's/skip-federated/#skip-federated/g' /etc/my.cnf
/usr/local/mysql/bin/mysql_install_db --user=mysql
chmod +w /usr/local/mysql
chown -R mysql /usr/local/mysql/var
chgrp -R mysql /usr/local/mysql/.
cp /usr/local/mysql/share/mysql/mysql.server /etc/init.d/mysql
chmod 755 /etc/init.d/mysql
chkconfig --level 345 mysql on
service mysql start
/usr/local/mysql/bin/mysqladmin -u root password root
echo "/usr/local/mysql/lib/mysql" >> /etc/ld.so.conf
ldconfig
ln -s /usr/local/mysql/lib/mysql /usr/lib/mysql
ln -s /usr/local/mysql/include/mysql /usr/include/mysql
service mysql stop
service mysql start
