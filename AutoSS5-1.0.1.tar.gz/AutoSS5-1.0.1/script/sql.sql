/*
SQLyog ��ҵ�� - MySQL GUI v5.02
���� - 5.1.31-log : ���ݿ� - pam
*********************************************************************
�������汾 : 5.1.31-log
*/


create database if not exists `pam`;

USE `pam`;

SET FOREIGN_KEY_CHECKS=0;

/*���ݱ� `admin` �ı��ṹ*/

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*���ݱ� `admin` ������*/

LOCK TABLES `admin` WRITE;

insert into `admin` values 
(1,'admin','admin');

UNLOCK TABLES;

/*���ݱ� `user` �ı��ṹ*/

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `active` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*���ݱ� `user` ������*/

LOCK TABLES `user` WRITE;

insert into `user` values 
(1,'test','test',1);

UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS=1;
