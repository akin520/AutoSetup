<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_ss5 = "10.88.2.89";
$database_ss5 = "pam";
$username_ss5 = "root";
$password_ss5 = "root";
$ss5 = mysql_pconnect($hostname_ss5, $username_ss5, $password_ss5) or trigger_error(mysql_error(),E_USER_ERROR); 
?>