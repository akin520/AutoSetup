<?php require_once('Connections/goto.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_goto = "-1";
if (isset($_GET['id'])) {
  $colname_goto = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_goto, $goto);
$query_goto = sprintf("SELECT * FROM url WHERE id = %s", GetSQLValueString($colname_goto, "int"));
$goto = mysql_query($query_goto, $goto) or die(mysql_error());
$row_goto = mysql_fetch_assoc($goto);
$totalRows_goto = mysql_num_rows($goto);
 
//header("Location:($url)");

mysql_free_result($goto);
?>
<html><head><title>ҳ����ת��....</title>
</head> 
<body> 
<script language='javascript'>document.location = "<?php echo $row_goto['url']; ?>"</script>
</body> 
</html>