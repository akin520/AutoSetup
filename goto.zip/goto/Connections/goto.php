<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_goto = "localhost";
$database_goto = "goto";
$username_goto = "root";
$password_goto = "root";
$goto = mysql_pconnect($hostname_goto, $username_goto, $password_goto) or trigger_error(mysql_error(),E_USER_ERROR); 
?>