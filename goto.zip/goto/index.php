<?php require_once('Connections/goto.php'); ?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['user'])) {
  $loginUsername=$_POST['user'];
  $password=$_POST['passwd'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "admin.php";
  $MM_redirectLoginFailed = "index.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_goto, $goto);
  
  $LoginRS__query=sprintf("SELECT user, passwd FROM admin WHERE user='%s' AND passwd='%s'",
    get_magic_quotes_gpc() ? $loginUsername : addslashes($loginUsername), get_magic_quotes_gpc() ? $password : addslashes($password)); 
   
  $LoginRS = mysql_query($LoginRS__query, $goto) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>GOTO������¼</title>
<style type="text/css">
<!--
.STYLE1 {font-size: xx-large}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
  <table width="343" height="187" border="1" align="center">
    <tr>
      <td height="62" colspan="2"><div align="center" class="STYLE1">GOTO������¼</div></td>
    </tr>
    <tr>
      <td width="96" height="34"><div align="center">�û���</div></td>
      <td width="231"><label>
        <input name="user" type="text" id="user" size="30" />        </label>      </td>
    </tr>
    <tr>
      <td height="31"><div align="center">����</div></td>
      <td><label>
        <input name="passwd" type="password" id="passwd" size="30" />        </label>      </td>
    </tr>
    <tr>
      <td height="48" colspan="2"><label>
        <input type="submit" name="Submit" value="��¼" />
      </label></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>
