<?php require_once('Connections/goto.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_goto, $goto);
$query_url = "SELECT * FROM url";
$url = mysql_query($query_url, $goto) or die(mysql_error());
$row_url = mysql_fetch_assoc($url);
$totalRows_url = mysql_num_rows($url);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>GOTO����ҳ</title>
<style type="text/css">
<!--
.STYLE1 {font-size: x-large}
-->
</style>
</head>

<body>
<p class="STYLE1">GOTO����ҳ</p>
<p class="STYLE1">&nbsp;</p>
<p class="STYLE1">||<a href="admin.php">������ҳ</a>||<a href="user.php">�û�����</a>||<a href="url.php">URL����</a>||</p>
<p class="STYLE1">&nbsp;</p>
<p class="STYLE1"><a href="url_add.php">����URL��ַ</a></p>
<table width="1001" height="55" border="1">
  <tr>
    <td colspan="5"><div align="center">URL����</div></td>
  </tr>
  <tr>
    <td><div align="center">id</div></td>
    <td><div align="center">˵��</div></td>
    <td><div align="center">urlַַ</div></td>
    <td colspan="2"><div align="center">����</div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td width="110"><div align="center"><?php echo $row_url['id']; ?></div></td>
      <td width="110"><?php echo $row_url['readme']; ?></td>
      <td width="482"><div align="left"><a href="goto.php?id=<?php echo $row_url['id']; ?>"><?php echo $row_url['url']; ?></a></div></td>
      <td width="130"><div align="center"><a href="url_edit.php?id=<?php echo $row_url['id']; ?>">�޸�</a></div></td>
      <td width="135"><div align="center"><a href="url_del.php?id=<?php echo $row_url['id']; ?>">ɾ��</a></div></td>
    </tr>
    <?php } while ($row_url = mysql_fetch_assoc($url)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($url);
?>
