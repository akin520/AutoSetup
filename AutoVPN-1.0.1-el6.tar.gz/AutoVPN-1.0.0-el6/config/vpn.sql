/*
SQLyog ��ҵ�� - MySQL GUI v5.02
���� - 5.0.22-log : ���ݿ� - radius
*********************************************************************
�������汾 : 5.0.22-log
*/


create database if not exists `radius`;

USE `radius`;

SET FOREIGN_KEY_CHECKS=0;

/*���ݱ� `admin` �ı��ṹ*/

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(25) default NULL,
  `pwd` varchar(25) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `admin` ������*/

LOCK TABLES `admin` WRITE;

insert into `admin` values 
(1,'admin','admin');

UNLOCK TABLES;

/*���ݱ� `nas` �ı��ṹ*/

DROP TABLE IF EXISTS `nas`;

CREATE TABLE `nas` (
  `id` int(10) NOT NULL auto_increment,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) default NULL,
  `type` varchar(30) default 'other',
  `ports` int(5) default NULL,
  `secret` varchar(60) NOT NULL default 'secret',
  `community` varchar(50) default NULL,
  `description` varchar(200) default 'RADIUS Client',
  PRIMARY KEY  (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `nas` ������*/

LOCK TABLES `nas` WRITE;

UNLOCK TABLES;

/*���ݱ� `radacct` �ı��ṹ*/

DROP TABLE IF EXISTS `radacct`;

CREATE TABLE `radacct` (
  `RadAcctId` bigint(21) NOT NULL auto_increment,
  `AcctSessionId` varchar(32) NOT NULL default '',
  `AcctUniqueId` varchar(32) NOT NULL default '',
  `UserName` varchar(64) NOT NULL default '',
  `Realm` varchar(64) default '',
  `NASIPAddress` varchar(15) NOT NULL default '',
  `NASPortId` varchar(15) default NULL,
  `NASPortType` varchar(32) default NULL,
  `AcctStartTime` datetime NOT NULL default '0000-00-00 00:00:00',
  `AcctStopTime` datetime NOT NULL default '0000-00-00 00:00:00',
  `AcctSessionTime` int(12) default NULL,
  `AcctAuthentic` varchar(32) default NULL,
  `ConnectInfo_start` varchar(50) default NULL,
  `ConnectInfo_stop` varchar(50) default NULL,
  `AcctInputOctets` bigint(12) default NULL,
  `AcctOutputOctets` bigint(12) default NULL,
  `CalledStationId` varchar(50) NOT NULL default '',
  `CallingStationId` varchar(50) NOT NULL default '',
  `AcctTerminateCause` varchar(32) NOT NULL default '',
  `ServiceType` varchar(32) default NULL,
  `FramedProtocol` varchar(32) default NULL,
  `FramedIPAddress` varchar(15) NOT NULL default '',
  `AcctStartDelay` int(12) default NULL,
  `AcctStopDelay` int(12) default NULL,
  PRIMARY KEY  (`RadAcctId`),
  KEY `UserName` (`UserName`),
  KEY `FramedIPAddress` (`FramedIPAddress`),
  KEY `AcctSessionId` (`AcctSessionId`),
  KEY `AcctUniqueId` (`AcctUniqueId`),
  KEY `AcctStartTime` (`AcctStartTime`),
  KEY `AcctStopTime` (`AcctStopTime`),
  KEY `NASIPAddress` (`NASIPAddress`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radacct` ������*/

LOCK TABLES `radacct` WRITE;

UNLOCK TABLES;

/*���ݱ� `radcheck` �ı��ṹ*/

DROP TABLE IF EXISTS `radcheck`;

CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `UserName` varchar(64) NOT NULL default '',
  `Attribute` varchar(32) NOT NULL default 'User-Password',
  `op` char(2) NOT NULL default ':=',
  `Value` varchar(253) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `UserName` (`UserName`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radcheck` ������*/

LOCK TABLES `radcheck` WRITE;

insert into `radcheck` values 
(1,'test','User-Password',':=','123456'),
(2,'admin','User-Password',':=','admin123');

UNLOCK TABLES;

/*���ݱ� `radgroupcheck` �ı��ṹ*/

DROP TABLE IF EXISTS `radgroupcheck`;

CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `GroupName` varchar(64) NOT NULL default '',
  `Attribute` varchar(32) NOT NULL default 'Simultaneous-Use',
  `op` char(2) NOT NULL default ':=',
  `Value` varchar(253) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `GroupName` (`GroupName`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radgroupcheck` ������*/

LOCK TABLES `radgroupcheck` WRITE;

insert into `radgroupcheck` values 
(1,'test','Simultaneous-Use',':=','1'),
(2,'admin','Simultaneous-Use',':=','100');

UNLOCK TABLES;

/*���ݱ� `radgroupreply` �ı��ṹ*/

DROP TABLE IF EXISTS `radgroupreply`;

CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `GroupName` varchar(64) NOT NULL default '',
  `Attribute` varchar(32) NOT NULL default '',
  `op` char(2) NOT NULL default '=',
  `Value` varchar(253) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `GroupName` (`GroupName`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radgroupreply` ������*/

LOCK TABLES `radgroupreply` WRITE;

UNLOCK TABLES;

/*���ݱ� `radpostauth` �ı��ṹ*/

DROP TABLE IF EXISTS `radpostauth`;

CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(64) NOT NULL default '',
  `pass` varchar(64) NOT NULL default '',
  `reply` varchar(32) NOT NULL default '',
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radpostauth` ������*/

LOCK TABLES `radpostauth` WRITE;

UNLOCK TABLES;

/*���ݱ� `radreply` �ı��ṹ*/

DROP TABLE IF EXISTS `radreply`;

CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `UserName` varchar(64) NOT NULL default '',
  `Attribute` varchar(32) NOT NULL default '',
  `op` char(2) NOT NULL default '=',
  `Value` varchar(253) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `UserName` (`UserName`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `radreply` ������*/

LOCK TABLES `radreply` WRITE;

UNLOCK TABLES;

/*���ݱ� `usergroup` �ı��ṹ*/

DROP TABLE IF EXISTS `usergroup`;

CREATE TABLE `usergroup` (
  `id` int(11) NOT NULL auto_increment,
  `UserName` varchar(64) NOT NULL default '',
  `GroupName` varchar(64) NOT NULL default '',
  `priority` int(11) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `UserName` (`UserName`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*���ݱ� `usergroup` ������*/

LOCK TABLES `usergroup` WRITE;

insert into `usergroup` values 
(1,'test','test',1),
(2,'admin','admin',1);

UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS=1;
