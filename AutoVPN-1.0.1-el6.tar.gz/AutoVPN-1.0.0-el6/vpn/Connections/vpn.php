<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_vpn = "10.0.0.4";
$database_vpn = "radius";
$username_vpn = "root";
$password_vpn = "root";
$vpn = mysql_pconnect($hostname_vpn, $username_vpn, $password_vpn) or trigger_error(mysql_error(),E_USER_ERROR); 
?>