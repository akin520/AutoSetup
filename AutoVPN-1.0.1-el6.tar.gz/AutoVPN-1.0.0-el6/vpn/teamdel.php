<?php require_once('Connections/vpn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

if ((isset($_GET['id'])) && ($_GET['id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM radgroupcheck WHERE id=%s",
                       GetSQLValueString($_GET['id'], "int"));

  mysql_select_db($database_vpn, $vpn);
  $Result1 = mysql_query($deleteSQL, $vpn) or die(mysql_error());

  $deleteGoTo = "vpnteam.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_team = "-1";
if (isset($_GET['id'])) {
  $colname_team = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_vpn, $vpn);
$query_team = sprintf("SELECT * FROM radgroupcheck WHERE id = %s", $colname_team);
$team = mysql_query($query_team, $vpn) or die(mysql_error());
$row_team = mysql_fetch_assoc($team);
$totalRows_team = mysql_num_rows($team);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>VPN+FreeRadius����ϵͳ</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #0066FF;
}
.style3 {font-size: 16px}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="531" height="288" border="0" align="center">
  <tr>
    <td width="144" rowspan="2"><a href="admin.php"><img src="image/dic.JPG" alt="" width="199" height="260" border="0" /></a></td>
    <td width="345" height="44" colspan="2"><div align="center" class="style1">VPN+FreeRadius����ϵͳ</div></td>
  </tr>
  <tr>
    <td height="238" colspan="2"><form id="form1" name="form1" method="POST">
      <table width="237" height="142" border="0" align="center">
        <tr>
          <td height="21" colspan="2"><div align="center" class="style3">VPN�����</div>
              <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div></td>
        </tr>
        <tr>
          <td height="10" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td width="83" height="10"><div align="center">VPN����</div></td>
          <td width="144" height="10"><div align="center">
            <label>
            <input name="groupname" type="text" id="groupname" value="<?php echo $row_team['GroupName']; ?>" />
            </label>
</div></td>
        </tr>
        <tr>
          <td height="37"><div align="center">�û���</div></td>
          <td height="37"><label>
            <input name="value" type="text" id="value" value="<?php echo $row_team['Value']; ?>" />
          </label></td>
        </tr>
        <tr>
          <td height="25" colspan="2"><div align="center">
            <label>
            <input type="submit" name="Submit" value="ɾ��" />
            </label>
            <label>
            <input type="reset" name="Submit2" value="����" />
            </label>
</div></td>
        </tr>
      </table>
      <p>
        <input name="id" type="hidden" id="id" value="<?php echo $row_team['id']; ?>" />
      </p>
        
      
      
    </form>
    <p>&nbsp;</p></td>
  </tr>
</table>
<div align="center"></div>
</body>
</html>
<?php
mysql_free_result($team);
?>