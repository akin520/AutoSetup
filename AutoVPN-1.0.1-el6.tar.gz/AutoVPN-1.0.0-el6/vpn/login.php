<?php require_once('Connections/vpn.php'); ?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['admin'])) {
  $loginUsername=$_POST['admin'];
  $password=$_POST['pwd'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "admin.php";
  $MM_redirectLoginFailed = "login.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_vpn, $vpn);
  
  $LoginRS__query=sprintf("SELECT name, pwd FROM admin WHERE name='%s' AND pwd='%s'",
    get_magic_quotes_gpc() ? $loginUsername : addslashes($loginUsername), get_magic_quotes_gpc() ? $password : addslashes($password)); 
   
  $LoginRS = mysql_query($LoginRS__query, $vpn) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>VPN+FreeRadius����ϵͳ</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #0066FF;
}
.style3 {font-size: 16px}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="531" height="288" border="0" align="center">
  <tr>
    <td width="144" rowspan="2"><img src="image/dic.JPG" width="199" height="260" alt="" /></td>
    <td width="345" height="44" colspan="2"><div align="center" class="style1">VPN+FreeRadius����ϵͳ</div></td>
  </tr>
  <tr>
    <td height="238" colspan="2"><form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
      <table width="245" height="109" border="0" align="center">
        <tr>
          <td width="97"><div align="center"><span class="style3">�û���</span></div></td>
          <td width="233"><label>
            <input name="admin" type="text" id="admin" />
          </label></td>
        </tr>
        <tr>
          <td><div align="center" class="style3">�� ��</div></td>
          <td><label>
            <input name="pwd" type="password" id="pwd" />
          </label></td>
        </tr>
        <tr>
          <td height="39" colspan="2"><label>
            <div align="center">
              <input type="submit" value="��¼" />
              <input name="Reset" type="reset" value="����" />
            </div>
          </label></td>
          </tr>
      </table>
        </form>
    </td>
  </tr>
</table>
<div align="center"></div>
</body>
</html>
