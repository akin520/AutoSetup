<?php require_once('Connections/vpn.php'); ?>
<?php
mysql_select_db($database_vpn, $vpn);
$query_sysuser = "SELECT * FROM `admin`";
$sysuser = mysql_query($query_sysuser, $vpn) or die(mysql_error());
$row_sysuser = mysql_fetch_assoc($sysuser);
$totalRows_sysuser = mysql_num_rows($sysuser);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>VPN+FreeRadius����ϵͳ</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #0066FF;
}
.style3 {font-size: 16px}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="531" height="288" border="0" align="center">
  <tr>
    <td width="144" rowspan="2"><a href="admin.php"><img src="image/dic.JPG" alt="" width="199" height="260" border="0" /></a></td>
    <td width="345" height="44" colspan="2"><div align="center" class="style1">VPN+FreeRadius����ϵͳ</div></td>
  </tr>
  <tr>
    <td height="238" colspan="2"><table width="237" height="49" border="0" align="center">
      <tr>
        <td height="45"><div align="center" class="style3">ϵͳ����</div>
            <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>
          <div align="center"></div>          <div align="center"></div></td>
      </tr>
      
    </table>
      <table width="237" border="0" align="center">
        <tr>
          <td width="58"><div align="center">ID</div></td>
          <td width="68"><div align="center">�û���</div></td>
          <td width="97"><div align="center">ɾ��</div></td>
        </tr>
        <div align="center"> </div>
          <?php do { ?>
            <tr>
              <td><div align="center"><?php echo $row_sysuser['id']; ?></div></td>
              <td><div align="center"><?php echo $row_sysuser['name']; ?></div></td>
              <td><div align="center"><a href="sysdel.php?id=<?php echo $row_sysuser['id']; ?>">ɾ��</a></div></td>
            </tr>
            <?php } while ($row_sysuser = mysql_fetch_assoc($sysuser)); ?>
          <div align="center"> </div>
      </table>
      <p>&nbsp;</p></td>
  </tr>
</table>
<div align="center"></div>
</body>
</html>
<?php
mysql_free_result($sysuser);
?>