#!/bin/bash
#author: badb0y (h3ewhack@163.com)
#clean all 
echo "clear......"
rm -rf myget*
rm -rf mysql*
rm -rf httpd*
rm -rf php*
rm -rf freetype*
rm -rf libpng*
rm -rf jpegsrc*
rm -rf libxml2*
rm -rf gd*
rm -rf Zend*
clear
echo "========================================================================="
echo "AutoMAP v 0.1.11 for RedHat  Written by badb0y "
echo "========================================================================="

if [ "$1" != "--help" ]; then

	install_path="/usr/local"
	echo "Please input the path you want to install to:"
	read -p "(Default Path: /usr/local):" install_path
	if [ "$install_path" = "" ]; then
		install_path="/usr/local"
	fi

	echo ""
	echo $AUTODIR
	echo $TOOLS_DIR
	echo $install_path
	echo
	read -p  "Press any key to download and install..."
#download tools
wget http://myget.sourceforge.net/release/myget-0.1.2.tar.gz
tar -zxvf myget-0.1.2.tar.gz
cd myget-0.1.2
./configure
make;make install
cd ..

/usr/local/bin/mytget -n 10 -f freetype-2.3.8.tar.gz http://autosetup1.googlecode.com/files/freetype-2.3.8.tar.gz
/usr/local/bin/mytget -n 10 -f gd-2.0.35.tar.gz http://autosetup1.googlecode.com/files/gd-2.0.35.tar.gz
/usr/local/bin/mytget -n 10 -f jpegsrc.v6b.tar.gz http://autosetup1.googlecode.com/files/jpegsrc.v6b.tar.gz
/usr/local/bin/mytget -n 10 -f libpng-1.2.35.tar.gz http://autosetup1.googlecode.com/files/libpng-1.2.35.tar.gz
/usr/local/bin/mytget -n 10 -f libxml2-2.7.3.tar.gz http://autosetup1.googlecode.com/files/libxml2-2.7.3.tar.gz
/usr/local/bin/mytget -n 10 -f mysql-5.1.31.tar.gz http://autosetup1.googlecode.com/files/mysql-5.1.31.tar.gz
/usr/local/bin/mytget -n 10 -f httpd-2.2.11.tar.gz http://autosetup1.googlecode.com/files/httpd-2.2.11.tar.gz
/usr/local/bin/mytget -n 10 -f php-5.2.9.tar.gz http://autosetup1.googlecode.com/files/php-5.2.9.tar.gz
/usr/local/bin/mytget -n 10 -f ZendOptimizer-3.3.3-linux-glibc23-i386.tar.gz http://autosetup1.googlecode.com/files/ZendOptimizer-3.3.3-linux-glibc23-i386.tar.gz

#install mysql
tar -zxvf mysql-5.1.31.tar.gz
cd mysql-5.1.31
./configure --prefix=$install_path/mysql --with-charset=utf8 --with-extra-charsets=all --enable-assembler --enable-thread-safe-client --with-big-tables --with-readline --with-ssl --with-embedded-server --enable-local-infile
make;make install
cd ..
groupadd mysql
useradd -g mysql mysql
cp $install_path/mysql/share/mysql/my-medium.cnf /etc/my.cnf
sed -i 's/skip-federated/#skip-federated/g' /etc/my.cnf
$install_path/mysql/bin/mysql_install_db --user=mysql
chmod +w $install_path/mysql
chown -R mysql $install_path/mysql/var
chgrp -R mysql $install_path/mysql/.
cp $install_path/mysql/share/mysql/mysql.server /etc/init.d/mysql
chmod 755 /etc/init.d/mysql
chkconfig --level 345 mysql on
service mysql start

#install apache
tar -zxvf httpd-2.2.11.tar.gz
cd httpd-2.2.11
./configure --prefix=$install_path/apache --enable-so --enable-track-vars --enable-mods-shared=all --enable-cache --enable-disk-cache --enable-mem-cache --enable-rewrite --with-mpm=worker
make;make install
cd ..
cat >httpd.txt<<EOF
#!/bin/bash
#
# Init file for Apache server daemon
#
# chkconfig: 2345 55 25
# description: Apache server daemon
#
# processname: httpd
EOF
cat httpd.txt $install_path/apache/bin/apachectl >/etc/init.d/httpd
rm -rf httpd.txt
chmod 755 /etc/init.d/httpd
chkconfig --level 345 httpd on
service httpd start

tar -zxvf freetype-2.3.8.tar.gz
cd  freetype-2.3.8
./configure --prefix=/usr
make;make install
cd ..

tar -zxvf libpng-1.2.35.tar.gz
cd libpng-1.2.35
./configure --prefix=/usr
make;make install
cd ..

tar -zxvf jpegsrc.v6b.tar.gz
cd jpeg-6b
mkdir -p /usr/man/man1/cjpeg.1
./configure --prefix=/usr --enable-static --enable-shared
make;make install
cd ..

tar -zxvf libxml2-2.7.3.tar.gz
cd libxml2-2.7.3
./configure --prefix=/usr
make;make install
cd ..

tar -zxvf gd-2.0.35.tar.gz
cd gd-2.0.35
./configure --prefix=/usr --with-freetype-dir --with-jpeg --with-png-dir
make;make install
cd ..

tar -zxvf php-5.2.9.tar.gz
cd php-5.2.9
./configure --prefix=$install_path/php --with-apxs2=$install_path/apache/bin/apxs --with-mysql=$install_path/mysql --with-config-file-path=$install_path/php/etc --with-gd --enable-gd-native-ttf --enable-gd-jis-conv --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --enable-xml --enable-mbstring
make;make install
cp php.ini-dist $install_path/php/etc/php.ini
cd ..

sed -i 's/index.html/index.html index.php/g' $install_path/apache/conf/httpd.conf
echo "AddType application/x-httpd-php .php" >>$install_path/apache/conf/httpd.conf
echo "AddType application/x-httpd-php-source .phps" >>$install_path/apache/conf/httpd.conf
cat >$install_path/apache/htdocs/info.php<<EOF
<?
phpinfo();
?>
EOF
service httpd stop
service httpd start
tar -zxvf ZendOptimizer-3.3.3-linux-glibc23-i386.tar.gz
cd ZendOptimizer-3.3.3-linux-glibc23-i386
./install.sh
clear
echo "========================================================================="
echo "AutoMAP v 0.1.11 for RedHat  Written by badb0y "
echo "apache:$install_path/apache"
echo "mysql :$install_path/mysql"
echo "php   :$install_path/php"
echo ""
echo "apache service: service httpd start/stop"
echo "mysql service: service mysql start/stop"
echo "========================================================================="


fi
