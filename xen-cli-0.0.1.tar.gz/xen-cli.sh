#!/bin/bash

CLI=/usr/bin/virsh
CLONE=/usr/bin/virt-clone
XM=$USER
XMPATH=/vm
TEMPLATE=template


#---------------------------------------------------------------#
#                                                               #
#Add the following content in sudoer                            #
##vi /etc/sudoers                                               #
#User_Alias      CLIUSERS = akin                                #
#Cmnd_Alias      VIRSH    = /usr/bin/virsh                      #
#Cmnd_Alias	 CLONE	  = /usr/bin/virt-clone                 #
#Cmnd_Alias	 RM       = /bin/rm                             #
#CLIUSERS        ALL      = NOPASSWD: VIRSH,CLONE,RM            #
#                                                               #
##chsh -s /bin/xen-cli.sh akin                                  #
#---------------------------------------------------------------#               

echo "---------------------------------------"
echo "xen-cli v0.0.1 Written by badb0y"
echo "Blog http://badb0y.cublog.cn"
echo "xen-cli v0.01 - type 'help' for help"
echo "---------------------------------------"


while true
do
cat <<MENU

MENU
echo -n "xen-cli >"
read host
case "$host" in
        boot)
	sudo $CLI start $XM
	;;
        console)
	sudo $CLI console $XM
	;;
	exit)
	exit
	;;
	help)
	echo "xen-cli v0.01"
        echo "boot     -  boot the xen guest."
        echo "console  -  Xen guest via the serial console."
        echo "exit     -  Exit the shell."
	echo "help     -  Show command."
	echo "quit     -  Exit the shell."
	echo "reboot   -  Reboot the xen guest."
	echo "shutdown -  Shutdown the xen guest."
	echo "status   -  Show the status of xen guest."
	echo "version  -  Show the version of this shell."
	echo "chpw     -  Change CLI password."
	echo "rebuild  -  rebuild OS!"
	;;
	quit)
	exit
	;;
	reboot)
        sudo $CLI reboot $XM
	;;
        shutdown)
	sudo $CLI shutdown $XM
	;;
        status)
	sudo $CLI dominfo $XM
	;;
	version)
	echo "xen-cli v 0.01"
	;;
	chpw)
	passwd
	;;
	rebuild)
	echo "Rebulid is runing undergroud, please wit for a few minutes to be finish!"
	sudo $CLI destroy $XM >/dev/null 2>&1
	sudo rm -rf /etc/xen/$XM >/dev/null 2>&1
	sudo rm -rf $XMPATH/$XM.img >/dev/null 2>&1
	echo "start clone files from template ......"
	sudo $CLONE -o $TEMPLATE -n $XM -f $XMPATH/$XM.img >/dev/null 2>&1
	echo "files are cloned from the template."
	echo "Your new root password is aiying"
	echo "Rebuild is finished!"
	;;
        *)
	echo "Error, No Command! xen-cli v0.01 - type 'help' for help"
	;;
esac
done
