<?php require_once('Connections/ovpnconn.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
mysql_select_db($database_ovpnconn, $ovpnconn);
$query_vpnu = "SELECT * FROM radcheck";
$vpnu = mysql_query($query_vpnu, $ovpnconn) or die(mysql_error());
$row_vpnu = mysql_fetch_assoc($vpnu);
$totalRows_vpnu = mysql_num_rows($vpnu);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>OVPN����ϵͳ</title>
<style type="text/css">
<!--
.style1 {font-size: 36px}
.style2 {font-size: 18px}
-->
</style>
</head>

<body>
<p class="style1">OVPN����ϵͳ</p>
<p class="style1">&nbsp;</p>
<p class="style2">|| <a href="admin.php">ϵͳ�û�����</a> || <a href="vpnu.php">VPN�û�����</a> || <a href="vpnb.php">VPN����ͳ��</a> ||</p>
<p class="style1">&nbsp;</p>
<form id="form1" name="form1" method="post" action="">
  <table width="368" border="1">
    <tr>
      <td colspan="3"><div align="center">VPN�û�������<a href="vpnu_add.php">����</a>��</div></td>
    </tr>
    <tr>
      <td width="112"><div align="center">vpn�û�</div></td>
      <td width="122"><div align="center">vpn����</div></td>
      <td width="112"><div align="center">����</div></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><div align="center"><?php echo $row_vpnu['UserName']; ?></div></td>
        <td><div align="center"><?php echo $row_vpnu['Value']; ?></div></td>
        <td><div align="center"><a href="vpnu_edit.php?id=<?php echo $row_vpnu['id']; ?>">�޸�</a> || <a href="vpnu_del.php?id=<?php echo $row_vpnu['id']; ?>">ɾ��</a> </div></td>
      </tr>
      <?php } while ($row_vpnu = mysql_fetch_assoc($vpnu)); ?>
  </table>
</form>
<p class="style1">&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($vpnu);
?>