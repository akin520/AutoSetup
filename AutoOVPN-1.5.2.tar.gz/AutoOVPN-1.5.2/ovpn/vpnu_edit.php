<?php require_once('Connections/ovpnconn.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE radcheck SET UserName=%s, `Value`=%s WHERE id=%s",
                       GetSQLValueString($_POST['user'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_ovpnconn, $ovpnconn);
  $Result1 = mysql_query($updateSQL, $ovpnconn) or die(mysql_error());

  $updateGoTo = "vpnu.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_vpnedit = "-1";
if (isset($_GET['id'])) {
  $colname_vpnedit = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_ovpnconn, $ovpnconn);
$query_vpnedit = sprintf("SELECT * FROM radcheck WHERE id = %s", $colname_vpnedit);
$vpnedit = mysql_query($query_vpnedit, $ovpnconn) or die(mysql_error());
$row_vpnedit = mysql_fetch_assoc($vpnedit);
$totalRows_vpnedit = mysql_num_rows($vpnedit);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 36px}
.style2 {font-size: 18px}
-->
</style>
</head>

<body>
<p class="style1">OVPN����ϵͳ</p>
<p class="style1">&nbsp;</p>
<p class="style2">|| <a href="admin.php">ϵͳ�û�����</a> || <a href="vpnu.php">VPN�û�����</a> || <a href="vpnb.php">VPN����ͳ��</a> ||</p>
<p class="style1"></p>
<p class="style1"></p>
<form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <table width="384" border="1">
    <tr>
      <td colspan="2"><div align="center">VPN�û��޸�</div></td>
    </tr>
    <tr>
      <td>VPN�û���</td>
      <td><label>
        <input name="user" type="text" id="user" value="<?php echo $row_vpnedit['UserName']; ?>" />
      </label></td>
    </tr>
    <tr>
      <td>VPN����</td>
      <td><label>
        <input name="pwd" type="text" id="pwd" value="<?php echo $row_vpnedit['Value']; ?>" />
      </label></td>
    </tr>
    <tr>
      <td colspan="2"><label>
        <input type="reset" name="Reset" value="��д" />
      </label>
        <label>
        <input type="submit" name="Submit2" value="�޸�" />
        <input name="id" type="hidden" id="id" value="<?php echo $row_vpnedit['id']; ?>" />
      </label></td>
    </tr>
  </table>
  <label></label>
  <input type="hidden" name="MM_update" value="form1">
</form>
<p class="style1"></p>
</body>
</html>
<?php
mysql_free_result($vpnedit);
?>
