<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_ovpnconn = "10.88.12.89";
$database_ovpnconn = "radius";
$username_ovpnconn = "root";
$password_ovpnconn = "root";
$ovpnconn = mysql_pconnect($hostname_ovpnconn, $username_ovpnconn, $password_ovpnconn) or trigger_error(mysql_error(),E_USER_ERROR); 
?>