<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>VPN+FreeRadius����ϵͳ</title>
<link href="image/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #0066FF;
}
.style3 {font-size: 16px}
-->
</style>

</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="531" height="288" border="0" align="center">
  <tr>
    <td width="144" rowspan="2"><img src="image/dic.JPG" width="199" height="260" alt="" /></td>
    <td width="345" height="44" colspan="2"><div align="center" class="style1">VPN+FreeRadius����ϵͳ</div></td>
  </tr>
  <tr>
    <td height="238" colspan="2"><table width="237" height="67" border="0" align="center">
      <tr>
        <td height="28" colspan="2"><div align="center" class="style3">ϵͳ����</div>          
        <div align="center"></div>
        <div align="center"></div>        <div align="center"></div></td>
        </tr>
      <tr>
        <td width="96" height="33"><div align="center"><a href="sys.php">ϵͳ����Ա</a></div>
            <div align="center"></div>            <div align="center"></div>            <div align="center"></div></td>
        <td width="131"><div align="center"><a href="sysadd.php">����</a> <a href="sysed.php">�޸�</a> <a href="sysd.php">ɾ��</a> </div>
            <div align="center"></div>            <div align="center"></div>            <div align="center"></div></td>
      </tr>
      
    </table>
    <table width="237" border="0" align="center">
        <tr>
          <td colspan="2"><div align="center"></div></td>
        </tr>
        <tr>
          <td colspan="2"><div align="center"><span class="style3">VPN����</span></div>            <div align="center"></div></td>
        </tr>
        <tr>
          <td width="143"><div align="center"><a href="vpnteam.php">VPN��</a></div></td>
          <td width="169"><div align="center"><a href="teamadd.php">����</a> <a href="teamed.php">�޸�</a> <a href="teamd.php">ɾ��</a> </div></td>
        </tr>
        <tr>
          <td height="17"><div align="center"><a href="vpnuser.php">VPN�û�</a></div></td>
          <td><div align="center"><a href="vpnadd.php">����</a> <a href="vpned.php">�޸�</a> <a href="vpned.php">ɾ��</a> </div></td>
        </tr>
      </table>      
    <p>&nbsp;</p></td>
  </tr>
</table>
<div align="center"></div>
</body>
</html>
