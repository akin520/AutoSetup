<?php require_once('Connections/vpn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE radcheck SET UserName=%s, `Value`=%s WHERE id=%s",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['value'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_vpn, $vpn);
  $Result1 = mysql_query($updateSQL, $vpn) or die(mysql_error());

  $updateGoTo = "vpnuser.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE usergroup SET UserName=%s, GroupName=%s WHERE id=%s",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['groupname'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_vpn, $vpn);
  $Result1 = mysql_query($updateSQL, $vpn) or die(mysql_error());
}

$colname_vpnedit = "-1";
if (isset($_GET['id'])) {
  $colname_vpnedit = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_vpn, $vpn);
$query_vpnedit = sprintf("SELECT * FROM radcheck WHERE id = %s", $colname_vpnedit);
$vpnedit = mysql_query($query_vpnedit, $vpn) or die(mysql_error());
$row_vpnedit = mysql_fetch_assoc($vpnedit);
$totalRows_vpnedit = mysql_num_rows($vpnedit);

$colname_vpnedit2 = "-1";
if (isset($_GET['id'])) {
  $colname_vpnedit2 = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_vpn, $vpn);
$query_vpnedit2 = sprintf("SELECT * FROM usergroup WHERE id = %s", $colname_vpnedit2);
$vpnedit2 = mysql_query($query_vpnedit2, $vpn) or die(mysql_error());
$row_vpnedit2 = mysql_fetch_assoc($vpnedit2);
$totalRows_vpnedit2 = mysql_num_rows($vpnedit2);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>VPN+FreeRadius����ϵͳ</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	color: #0066FF;
}
.style3 {font-size: 16px}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="531" height="288" border="0" align="center">
  <tr>
    <td width="144" rowspan="2"><a href="admin.php"><img src="image/dic.JPG" alt="" width="199" height="260" border="0" /></a></td>
    <td width="345" height="44" colspan="2"><div align="center" class="style1">VPN+FreeRadius����ϵͳ</div></td>
  </tr>
  <tr>
    <td height="238" colspan="2"><form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
      <table width="245" height="173" border="0" align="center">
        <tr>
          <td height="21" colspan="2"><div align="center" class="style3">VPN�û�����</div>
              <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div>
            <div align="center"></div></td>
        </tr>
        <tr>
          <td height="10" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td width="83" height="10"><div align="center">VPN�û���</div></td>
          <td width="144" height="10"><div align="center">
            <label>
            <input name="username" type="text" id="username" value="<?php echo $row_vpnedit['UserName']; ?>" />
            </label>
</div></td>
        </tr>
        <tr>
          <td height="17"><div align="center">VPN�û���</div>            <label></label></td>
          <td height="17"><label>
            <input name="groupname" type="text" id="groupname" value="<?php echo $row_vpnedit2['GroupName']; ?>" />
          </label></td>
        </tr>
        <tr>
          <td height="18"><div align="center">VPN����</div></td>
          <td height="18"><label>
            <input name="value" type="text" id="value" value="<?php echo $row_vpnedit['Value']; ?>" />
          </label></td>
        </tr>
        <tr>
          <td height="25" colspan="2"><div align="center">
            <label>
            <input type="submit" name="Submit" value="�޸�" />
            </label>
            <label>
            <input type="reset" name="Submit2" value="����" />
            </label>
</div></td>
        </tr>
      </table>
      <p>
        <input name="id" type="hidden" id="id" value="<?php echo $row_vpnedit['id']; ?>" />
      </p>
        
      
      
      <input type="hidden" name="MM_update" value="form1">
    </form>
    <p>&nbsp;</p></td>
  </tr>
</table>
<div align="center"></div>
</body>
</html>
<?php
mysql_free_result($vpnedit);

mysql_free_result($vpnedit2);
?>