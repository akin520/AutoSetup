grant all on *.* to root@'%' identified by 'root'
